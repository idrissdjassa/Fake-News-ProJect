import React from 'react'

export default function About() {
  return (
    <div>
      <h1>About Fake News Site</h1>
      <p>This is the about page.</p>
    </div>
  )
}
